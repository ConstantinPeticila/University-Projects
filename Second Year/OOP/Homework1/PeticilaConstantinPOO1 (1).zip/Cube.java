
/**
 * @author Peticila Constantin
 * Cubul unui numar
 */

public class Cube extends Procese  {
    /**
     * callculeaza cubul folosint functia MAth;
     * @param a numarul intreg pentru care se calculeaza numarul
     * @return cubul numarului
     */

    public int proces (int a ){
        return (int)Math.pow(a,3);
    }
}
